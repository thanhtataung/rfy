﻿
namespace RfyRedPill.BusinessLogic
{
    //To store all constant value
    public class Constant
    {
        public const int MaxIndex = 92;
        public const int MinIndex = -92;
    }
}
